package com.example.jesus.wilsonreminder2;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;

public class RegistroUsuario extends AppCompatActivity {

    private View activity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_usuario);
        Toolbar toolbar = (Toolbar) findViewById(R.id.tittleRegistrar);
        setSupportActionBar(toolbar);

    }

    public View getActivity(){
        return activity;
    }

    /*public void validacionNombre(View view){
        EditText nombre = (EditText) getActivity().findViewById(R.id.txtNombre);
        if ()
    }*/

    public void registrado(View view){
        Intent login = new Intent(this, MainInicio.class);
        startActivity(login);
    }

}
