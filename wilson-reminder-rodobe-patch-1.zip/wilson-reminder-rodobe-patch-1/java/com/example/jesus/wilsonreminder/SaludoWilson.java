package com.example.jesus.wilsonreminder;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class SaludoWilson extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saludo_wilson);
    }
}
